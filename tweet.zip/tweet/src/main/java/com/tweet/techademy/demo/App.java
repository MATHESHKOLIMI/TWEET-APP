package com.tweet.techademy.demo;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import com.tweet.techademy.demo.controller.TweetController;
import com.tweet.techademy.demo.dao.RegistrationDao;
import com.tweet.techademy.demo.dao.Impl.RegistrationDaoImpl;

/**
 * Hello world!
 *
 */
@SpringBootApplication
public class App {
	
//	static RegistrationDaoImpl register = new RegistrationDaoImpl();
//	static TweetController controller = new TweetController();

	public static void main(String[] args) {
//        controller.getData();
//		Calendar cal = Calendar.getInstance();
//		SimpleDateFormat format = new SimpleDateFormat("MMM-YY");
//		String month = format.format(cal.getTime());
//		Scanner scan = new Scanner(System.in);
//		char ch;
//		do {
//			System.out.println("enter l for login and r for register");
//			ch = scan.next().charAt(0);
//			switch (ch) {
//			case 'r':
//				register.registerUser();
//				break;
//			case 'l':
//				register.login();
//				break;
//			default:
//				System.out.println("no a valid option");
//				break;
//			}
//			System.out.println("do you want to continue with login press y");
//		} while ((ch = scan.next().charAt(0)) == 'y' || (ch = scan.next().charAt(0)) == 'Y');
		SpringApplication.run(App.class, args);
	}
}

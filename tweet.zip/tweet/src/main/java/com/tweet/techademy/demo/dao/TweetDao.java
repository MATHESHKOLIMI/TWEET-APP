package com.tweet.techademy.demo.dao;

import java.util.List;

import com.tweet.techademy.demo.model.Tweet;

public interface TweetDao {
	public List<Tweet> getAllTweetsPostedByAllUsers() throws Exception;
	public List<Tweet> getAllTweetsPostedByUser(String ownerName) throws Exception;
	public void postTweet(Tweet tweet) throws Exception ;
}

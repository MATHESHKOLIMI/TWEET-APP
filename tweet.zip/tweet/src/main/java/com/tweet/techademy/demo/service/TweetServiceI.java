package com.tweet.techademy.demo.service;

import com.tweet.techademy.demo.model.Tweet;

public interface TweetServiceI {
	
	public boolean postTweet(Tweet tweet);
}

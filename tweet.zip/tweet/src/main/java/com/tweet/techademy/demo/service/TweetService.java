package com.tweet.techademy.demo.service;

import java.text.Format;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.tweet.techademy.demo.dao.TweetDao;
import com.tweet.techademy.demo.dao.Impl.TweetDaoImpl;
import com.tweet.techademy.demo.model.Tweet;
import com.tweet.techademy.demo.repository.TweetRepository;

@Service
public class TweetService implements TweetServiceI {
	@Autowired
	private TweetRepository tweetRepo;
	
	public TweetDao tweetServe=new TweetDaoImpl();
	public List<Tweet> getAllTweets() throws Exception {
		List<Tweet> listOfTweets=new ArrayList<Tweet>();
		listOfTweets=tweetServe.getAllTweetsPostedByAllUsers();
		listOfTweets.stream().peek(s-> System.out.println(s.getTweetOwner()+" "+s.getTweetMessage()+" "+s.getTweetDate())).count();
		return listOfTweets;
	}
	
	public List<Tweet> getAllTweetsByUser(String userName) throws Exception {
		List<Tweet> listOfTweets=new ArrayList<Tweet>();
		listOfTweets = tweetServe.getAllTweetsPostedByUser(userName);
		listOfTweets.stream().peek(s-> System.out.println(s.getTweetMessage()+"    - by "+s.getTweetOwner()+"    ("+s.getTweetDate()+")")).count();
		return listOfTweets;
	}
	
	public boolean postTweet(Tweet tweetMessage) {
//		Tweet tweet=new Tweet();
//		scan.nextLine();
		try {
//			System.out.println("enter the tweet message");
//			String message=scan.nextLine();
//			tweet.setTweetId(4);
			Integer idd= (int)(Math.random()*100000);
			tweetMessage.setTweetId(idd.toString());
//			tweet.setTweetOwner(tweetMessage.getTweetOwner());
//			tweet.setTweetDate(LocalDate.now().toString());
//			tweet.setTweetMessage(tweetMessage.getTweetMessage());
			tweetRepo.save(tweetMessage);
//			tweetServe.postTweet(tweet);
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println(e.getMessage());
			return false;
		}
		return true;
	}
	
	public List<Tweet> getAllTweetsPostedByMe(String loggedUser) throws Exception{
//		List<Tweet> listOfTweets=new ArrayList<Tweet>();
//		listOfTweets = tweetServe.getAllTweetsPostedByUser(loggedUser);
//		listOfTweets.stream().peek(s-> System.out.println(s.getTweetMessage()+"    - by "+s.getTweetOwner()+"    ("+s.getTweetDate()+")")).count();
//		return listOfTweets;
		
		List<Tweet> tweetList=new ArrayList<Tweet>();
		try {
			tweetList=tweetRepo.findAllByTweetOwner(loggedUser);
//			tweetList=tweetRepo.findAll();
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}
		return tweetList;
	}
}

package com.tweet.techademy.demo.model;

//import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Tweets")
public class Tweet {
	@Id
	private String id;
	private String tweetId;
	private String tweetMessage;
	private String tweetOwner;
	private String tweetDate;
	
	
	public String getTweetId() {
		return tweetId;
	}
	public void setTweetId(String tweetId) {
		this.tweetId = tweetId;
	}
	public String getTweetMessage() {
		return tweetMessage;
	}
	public void setTweetMessage(String tweetMessage) {
		this.tweetMessage = tweetMessage;
	}
	public String getTweetOwner() {
		return tweetOwner;
	}
	public void setTweetOwner(String tweetOwner) {
		this.tweetOwner = tweetOwner;
	}
	public String getTweetDate() {
		return tweetDate;
	}
	public void setTweetDate(String tweetDate) {
		this.tweetDate = tweetDate;
	}
	public Tweet() {
		super();
	}
	public Tweet(String tweetId, String tweetMessage, String tweetOwner, String tweetDate) {
		super();
		this.tweetId = tweetId;
		this.tweetMessage = tweetMessage;
		this.tweetOwner = tweetOwner;
		this.tweetDate = tweetDate;
	}
	
	
}

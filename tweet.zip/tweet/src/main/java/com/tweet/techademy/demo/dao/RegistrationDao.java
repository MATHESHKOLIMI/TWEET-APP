package com.tweet.techademy.demo.dao;

import com.tweet.techademy.demo.model.User;

public interface RegistrationDao{
	public void registerUser(User user);	
}

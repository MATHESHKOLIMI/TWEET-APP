package com.tweet.techademy.demo.dao.Impl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.repository.config.EnableMongoRepositories;
import org.springframework.stereotype.Service;

import com.tweet.techademy.demo.dao.TweetDao;
import com.tweet.techademy.demo.model.Tweet;
import com.tweet.techademy.demo.repository.TweetRepository;

@Service
@EnableMongoRepositories(basePackages = "com.tweet.techademy.demo.repository")
public class TweetDaoImpl implements TweetDao {
	
	@Autowired
	private TweetRepository tweetRepository;
	
	public Connection getConnection() throws Exception {
		GeneralDbConnection dbConnection=new GeneralDbConnection();
		return dbConnection.getConnection();
	}
	@Override
	public List<Tweet> getAllTweetsPostedByAllUsers() throws Exception {
//		tweetRepository.fin
		Connection con=getConnection();
		List<Tweet> listOfTweets=new ArrayList<Tweet>();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from tweet");
			ResultSet result=stmt.executeQuery();
			while(result.next()) {
				Tweet tweet=new Tweet();
				tweet.setTweetId(result.getString("tweet_id"));
				tweet.setTweetOwner(result.getString("tweet_owner"));
				tweet.setTweetMessage(result.getString("tweet_message"));
				tweet.setTweetDate(result.getString("tweet_date"));
				listOfTweets.add(tweet);
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			con.close();
		}
		return listOfTweets;
	}

	@Override
	public List<Tweet> getAllTweetsPostedByUser(String ownerName) throws Exception{
		Connection con=getConnection();
		List<Tweet> listOfTweets=new ArrayList<Tweet>();
		try {
			PreparedStatement stmt=con.prepareStatement("select * from tweet where tweet_owner=?");
			stmt.setString(1, ownerName);
			ResultSet result=stmt.executeQuery();
			while(result.next()) {
				Tweet tweet=new Tweet();
				tweet.setTweetId(result.getString("tweet_id"));
				tweet.setTweetOwner(result.getString("tweet_owner"));
				tweet.setTweetMessage(result.getString("tweet_message"));
				tweet.setTweetDate(result.getString("tweet_date"));
				listOfTweets.add(tweet);
			}
		}
		catch (Exception e) {
			// TODO: handle exception
		}
		finally {
			con.close();
		}
		return listOfTweets;
	}

	@Override
	public void postTweet(Tweet tweetLocal) throws Exception {
//		Connection con=getConnection();
//		Calendar cal=Calendar.getInstance();
//		java.util.Date date=new java.util.Date(cal.getTime().getTime());
		try {
//			PreparedStatement stmt=con.prepareStatement("insert into tweet(tweet_id,tweet_message , tweet_owner, tweet_date) values(?,?,?,?)");
//			stmt.setString(1, tweet.getTweetId());
//			stmt.setString(2, tweet.getTweetMessage());
//			stmt.setString(3, tweet.getTweetOwner());
//			stmt.setString(4,tweet.getTweetDate());
//			stmt.execute();
			
			tweetRepository.save(tweetLocal);
				System.out.println("successful");
		} catch (NullPointerException e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("exception");
			throw new Exception();
		}
		finally {
//			con.close();
		}
	}
}

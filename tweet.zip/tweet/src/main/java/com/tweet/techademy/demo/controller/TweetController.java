package com.tweet.techademy.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
//import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.tweet.techademy.demo.dao.Impl.RegistrationDaoImpl;
import com.tweet.techademy.demo.model.Response;
import com.tweet.techademy.demo.model.Tweet;
import com.tweet.techademy.demo.model.User;
import com.tweet.techademy.demo.repository.TweetRepository;
import com.tweet.techademy.demo.service.TweetService;
import com.tweet.techademy.demo.service.TweetServiceI;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class TweetController {

//	private TweetService tweetService=new TweetService();
	
	@Autowired
	private TweetService tweetServiceI;
	
//	@Autowired
//	private TweetRepository tweetRepositoryin;
	
	RegistrationDaoImpl registerService =new RegistrationDaoImpl();
	@RequestMapping(value = "/get-tweets", method = RequestMethod.GET)
	public List<Tweet> gettweets() throws Exception {
		return tweetServiceI.getAllTweets();
	}
	
	@RequestMapping(value = "/get-my-tweets/{loggedInUser}", method = RequestMethod.GET)
	public List<Tweet> getMyTweets(@PathVariable String loggedInUser) throws Exception {
//		List<Tweet> tweets=tweetRepositoryin.findAll();
//		System.out.println(tweets.get(1));
		return tweetServiceI.getAllTweetsPostedByMe(loggedInUser);
	}
	@RequestMapping(value = "/get-tweet-by-username/{userName}", method = RequestMethod.GET)
	public List<Tweet> getTweetsByUserName(@PathVariable String userName) throws Exception {
		return tweetServiceI.getAllTweetsByUser(userName);
	}
	@RequestMapping(value = "/post-tweet", method = RequestMethod.POST)
	public Tweet postTweet(@RequestBody Tweet message) {
		System.out.println("/post-tweet is called");
//		tweetRepositoryin.save(message);
//		return message;
		Integer idd= (int)(Math.random()*100000);
		message.setTweetId(idd.toString());
//		tweetRepositoryin.save(message);
		tweetServiceI.postTweet(message);
		return message;
	}
	
	@RequestMapping(value = "/get-user", method = RequestMethod.POST)
	public Response getUserByEmail(@RequestBody User user) throws Exception {
		Response response=new Response();
		response.setStatus(registerService.login(user.getEmail(), user.getPassword()));
		return response;
		
	}
	
	@RequestMapping(value = "/create-user", method = RequestMethod.POST)
	public Response createUser(@RequestBody User user) throws Exception {
		Response response=new Response();
		Integer i;
		StringBuffer id= new StringBuffer();
		do {
		i= (int)(Math.random()*10);
		id.append(i);
		}while(id.length()!=5);
		user.setId(id.toString());
		response.setStatus(registerService.registerUser(user));
		return response;
		
	}
	
	@RequestMapping(value = "/reset-password", method = RequestMethod.POST)
	public Response resetPassword(@RequestBody User users[]) throws Exception {
		Response response=new Response();
		User user=users[0];
		User updatedPassword=users[1];
		User registeredUser=registerService.getUser(user);
		if(registeredUser.getPassword().equals(user.getPassword())) {
			registeredUser.setPassword(updatedPassword.getPassword());
			response.setStatus(registerService.updatePassword(registeredUser));
		}
		return response;
		
	}
}

package com.tweet.techademy.demo.dao.Impl;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class GeneralDbConnection {
	public Connection getConnection() throws Exception {
		FileReader reader = new FileReader("C:/Users/User/CaseStudy/tweet/src/main/resources/db.properties");

		Properties p = new Properties();
		p.load(reader);

		Class.forName(p.getProperty("Driver"));
		Connection con = DriverManager.getConnection(p.getProperty("MysqlURL"), p.getProperty("userName"),
				p.getProperty("password"));
		return con;
	}
}

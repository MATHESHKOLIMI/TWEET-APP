package com.tweet.techademy.demo.model;



import java.util.Date;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.DateTimeFormat.ISO;



public class User {
	private String userId;
//	@NotNull
	@Pattern(regexp="^(?=.*[a-z])(?=.*[A-Z]).{6,15}$")
	private String firstName;
	
//	@NotNull
	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z]).{1,15}$")
	private String lastName;
	
	private String gender;
	
	@DateTimeFormat(iso = ISO.DATE_TIME)
	private Date dateOfBirth;
	
//	@NotNull
	@Email
	private String email;
	
//	@NotNull
	@Pattern(regexp = "^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[@$#%])(?=\\\\S+$).{8,16}$")
	private String password;
	
	public User() {
		super();
	}
	
	
	public User(String firstName, String lastName, String gender, Date dateOf_Birth, String email, String password) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.dateOfBirth = dateOf_Birth;
		this.email = email;
		this.password = password;
	}
	public String getId() {
		return userId;
	}


	public void setId(String id) {
		this.userId = id;
	}


	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public Date getDateOfBirth() {
		return dateOfBirth;
	}
	public void setDateOfBirth(Date dateOf_Birth) {
		this.dateOfBirth = dateOf_Birth;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}

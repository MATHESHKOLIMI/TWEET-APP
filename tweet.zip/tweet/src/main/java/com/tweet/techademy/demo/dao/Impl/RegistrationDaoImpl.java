package com.tweet.techademy.demo.dao.Impl;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.Properties;
import java.util.Scanner;

import org.springframework.beans.factory.annotation.Value;

import com.tweet.techademy.demo.dao.RegistrationDao;
import com.tweet.techademy.demo.dao.TweetDao;
import com.tweet.techademy.demo.model.Tweet;
import com.tweet.techademy.demo.model.User;
import com.tweet.techademy.demo.service.TweetService;

public class RegistrationDaoImpl {//implements RegistrationDao {

	Scanner scan = new Scanner(System.in);

	public Connection getConnection() throws Exception {
		GeneralDbConnection dbConnection=new GeneralDbConnection();
		return dbConnection.getConnection();
	}
	
	public TweetService tweetService=new TweetService();

	public String registerUser(User registerUser) {
		User user = new User();
//		System.out.println(demo);
//		System.out.println("to Register plese enter the details");
		try {
			Connection connect = getConnection();
			String SQL = "insert into Users(Id,FIRST_NAME,LAST_NAME,GENDER,DATE_OF_BIRTH,EMAIL,PASSWORD) values(?,?,?,?,?,?,?)";
			PreparedStatement statement = connect.prepareStatement(SQL);
			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
//			System.out.println("enter User ID");
//			user.setId(registerUser.getId());
			statement.setString(1, registerUser.getId());
//			System.out.println("enter User First Name");
//			user.setFirstName(registerUser.getFirstName());
			statement.setString(2, registerUser.getFirstName());
//			System.out.println("enter User Last Name");
//			user.setLastName(registerUser.getLastName());
			statement.setString(3, registerUser.getLastName());
//			System.out.println("enter User Gender");
//			user.setGender(scan.nextLine());
			statement.setString(4, "male");
//			System.out.println("enter User DOB");
//			try {
//				user.setDateOfBirth(formatter.parse(scan.nextLine()));
//			} catch (Exception e) {
//				throw new Exception("please enter dob in this format and try again YYYY-MM-DD");
//			}
//			statement.setString(5, formatter.format(user.getDateOfBirth()));
			statement.setString(5, "1998-06-06");
//			do {
////			System.out.println("enter User Email");
////			user.setEmail(scan.nextLine());
//			}while(checkForExistingEmail(registerUser.getEmail()));
			statement.setString(6, registerUser.getEmail());
//			System.out.println("enter User password");
//			user.setPassword(scan.nextLine());
			statement.setString(7, registerUser.getPassword());
			statement.execute();
//			if(statement.execute()) {
				
//			}
			connect.close();
			System.out.println("User registered successfuly");
//			System.out.println("press the following key for further assistance");
//			System.out.println("1- Login \t 2 - exit");
//			String option=scan.nextLine();
//			switch (option) {
//			case "1":
//				login();
//				break;
//			case "2":
//				System.out.println("Thank You");
//				break;
//			default:
//				System.out.println("please enter a valid option");
//				break;
//			}

			return "Success";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			System.out.println("User Registration Failed!! please register with valid Details");
			e.printStackTrace();
			return "Failed";
		}
	}

	private boolean checkForExistingEmail(String email) {
		// TODO Auto-generated method stub
		Connection con;
		try {
			con = getConnection();
			PreparedStatement statement= con.prepareStatement("select * from Users where email=?");
			statement.setString(1, email);
			ResultSet rs=statement.executeQuery();
			
			if(rs.next() && rs.getString("email").equals(email)) {
				System.out.println("email already Exists please enter other valid email or proceed with login");
				return true;
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return false;
	}

	public String login(String userName, String password) {
//		char ch='n';
//		String loginStatus="";
//		System.out.println("please login with you credentials !!");
//		System.out.println("Username/Email");
//		String email=scan.nextLine();
//		do {
//		System.out.println("password");
//		String password=scan.nextLine();
		try {
			Connection con=getConnection();
			PreparedStatement statement= con.prepareStatement("select * from Users where email=?");
			statement.setString(1, userName);
			ResultSet rs=statement.executeQuery();
//			statement.getResultSet();
			if(rs.next()) {
				if(password.equals(rs.getString("password"))) {
//					System.out.println("login Successful");
//					loginStatus="SUCCESS";
					String name=rs.getString("email");
//					action(name);
					User loggedInUser= new User(rs.getString(2),rs.getString(3),rs.getString(4),rs.getDate(5),rs.getString(6),rs.getString(7));
					loggedInUser.setId(rs.getString(1));
					return "Success";
				}
				else {
					return "Failed";
//					System.out.println("login denied\n");
//					loginStatus="DENIED";
//					throw new Exception("login Exception - please enter valid credentials!!");
				}
			}
			con.close();
			return "Failed";
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return "Failed";
		}
//		if(!loginStatus.equals("SUCCESS")) {
//		System.out.println("try again? y/n");
//		ch=scan.nextLine().charAt(0);
//		}else {
//			break;
//		}
//		scan.nextLine();
//		}while(ch=='y'|| ch=='Y');
		
	}

	public void action( String userName) throws Exception{
		Scanner sc=new Scanner(System.in);
		int option1;
		do {
		System.out.println("enter \n"+
		"1- view all tweets posted by all users \n"+
		"2-view all tweets posted by you \n" +
		"3- post a tweet \n" +
		"0- exit app");
		option1=sc.nextInt();
		switch(option1) {
		case 0:
			break;
		case 1:
			tweetService.getAllTweets();
			break;
		case 2:
			tweetService.getAllTweetsByUser(userName);
			break;
		case 3:
//			if(tweetService.postTweet(userName,sc)){
//				System.out.println("tweet posted successfully");
//			}
//			else {
//				System.out.println("tweet failed to post");
//			}
			break;
		default :
			System.out.println("please enter a valid option or 0 to exit");
			break;
		}
		}while(option1!=0);
	}

	public User getUser(User user) {

		User loggedUser=new User();
		try {
			Connection connect=getConnection();
			String sql="select * from users where email=?";
			PreparedStatement statement=connect.prepareStatement(sql);
			statement.setString(1, user.getEmail());
			ResultSet rs= statement.executeQuery();
			while(rs.next()) {
				loggedUser.setEmail(rs.getString("email"));
				loggedUser.setPassword(rs.getString("password"));
			}
		}catch(Exception e) {
			return new User();
		}
		return loggedUser;
	}
	
	public String updatePassword(User user) {
		User loggedUser=new User();
		try {
			Connection connect=getConnection();
			String sql="update users set password= ? where email= ?";
			PreparedStatement statement1=connect.prepareStatement(sql);
			statement1.setString(1, user.getPassword());
			statement1.setString(2, user.getEmail());
			statement1.execute();
			return "Updated";
		}
		catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
			System.out.println("password not updated");
			return "Failed";
		}
	}
}

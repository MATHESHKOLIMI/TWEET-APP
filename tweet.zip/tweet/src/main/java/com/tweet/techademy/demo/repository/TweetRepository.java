package com.tweet.techademy.demo.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.tweet.techademy.demo.model.Tweet;


public interface TweetRepository extends MongoRepository<Tweet, String> {
	
	public List<Tweet> findAllByTweetOwner(String tweetOwner);
}


import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {RegisterComponent} from '../app/registration/register/register.component'
import { LoginComponent } from './registration/login/login.component';
import { HomeComponent } from './registration/home/home.component';
import { MytweetComponent } from './registration/mytweet/mytweet.component';
import { AlltweetsComponent } from './registration/alltweets/alltweets.component';
import { ResetPasswordComponent } from './registration/reset-password/reset-password.component';
import { ForgotPasswordComponent } from './registration/forgot-password/forgot-password.component';
import { PostTweetComponent } from './registration/post-tweet/post-tweet.component';
import { HttpClientModule } from '@angular/common/http';

@NgModule({
  declarations: [
    AppComponent,
    RegisterComponent,
    LoginComponent,
    HomeComponent,
    MytweetComponent,
    AlltweetsComponent,
    ResetPasswordComponent,
    ForgotPasswordComponent,
    PostTweetComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    HttpClientModule,
  ],
  exports: [
    ReactiveFormsModule,
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }

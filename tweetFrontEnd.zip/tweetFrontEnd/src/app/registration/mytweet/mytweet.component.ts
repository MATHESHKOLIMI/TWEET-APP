
import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { SelectMultipleControlValueAccessor } from '@angular/forms';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PostService } from '../service/post.service';
import { Tweet } from '../Tweet';

@Component({
  selector: 'app-mytweet',
  templateUrl: './mytweet.component.html',
  styleUrls: ['./mytweet.component.css']
})
export class MytweetComponent implements OnInit {

  // data: Array<any>
  tweetOwner:String;
  getTweets:String;
  constructor(private router:Router, private post : PostService, private http: HttpClient) {
   }
   Tweets: any = [];
   allTweets:any = [];
  ngOnInit(): void {
    this.tweetOwner=localStorage.getItem('email');
    this.loadingTweet();
    // console.log(this.Tweets);
    // console.log(this.allTweets);
  }
  loadingTweet(){    
    return this.getTweet(this.tweetOwner).subscribe((data: Tweet) => {
       this.Tweets=data;
      console.log(data);
      this.showTweets();
    });
    console.log();
  }
  showTweets(){
    console.log(this.Tweets);
  }
  getTweet(owner) : Observable<Tweet>{
    return this.http.get<Tweet>("http://localhost:8090/get-my-tweets/"+owner);
  }
  
  postTweet(){
      this.router.navigateByUrl("/home/post");
      
  }
  // addTweetToMYTweet(){
  //     this.message=this.post.getTweetMessage();
  //     console.log(this.data);
  //     // localStorage.
  //     localStorage.removeItem('message');
  // }
}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../service/validation.service';
import { WebrequestService } from '../service/webrequest.service';
import { User } from '../User';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  resetForm: FormGroup;
  user:User;
  updatedUser:User;
  status: String;
  email=localStorage.getItem('email');
  submitted= false;
  constructor(private formbuilder:FormBuilder,private router: Router , private custom: ValidationService, private webRequest: WebrequestService) { }

  ngOnInit(): void {
    this.resetForm=this.formbuilder.group({
      oldPassword: ['', Validators.compose([Validators.required,this.custom.patternValidator()])],
      password: ['', Validators.compose([Validators.required,this.custom.patternValidator()])],
      confirmPassword: ['', [Validators.required]],
    },{
        validator: this.custom.MatchPassword('password','confirmPassword')});
    
  }

  get resetFormController(){
    return this.resetForm.controls;
  }

  submit(){
    // this.submitted=true;
    // if(this.resetForm.valid){
    //   console.table(this.resetForm.value);
    this.user={userId: null, email: this.email, password: this.resetFormController.oldPassword.value, dateOfBirth: null,firstName: null, lastName:null,gender:null};
    this.updatedUser={userId: null, email: this.email, password: this.resetFormController.password.value, dateOfBirth: null,firstName: null, lastName:null,gender:null};

    this.webRequest.resetUserPassword(this.user,this.updatedUser).subscribe((data: any)=>{
          this.status=data.status;
          if(this.status==="Updated"){
            alert('password updated successfuly!! \n please login');
            this.router.navigateByUrl("/login");
          }
          
    })
    }
  

}

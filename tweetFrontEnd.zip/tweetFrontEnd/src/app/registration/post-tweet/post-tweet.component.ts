import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import {MytweetComponent} from '../mytweet/mytweet.component';
import { PostService } from '../service/post.service';
import { WebrequestService } from '../service/webrequest.service';
import { Tweet } from '../Tweet';
@Component({
  selector: 'app-post-tweet',
  templateUrl: './post-tweet.component.html',
  styleUrls: ['./post-tweet.component.css']
})
export class PostTweetComponent implements OnInit {

  postTweet: FormGroup;
  messageTweet: Tweet;
  constructor(private formbuilder:FormBuilder, private router: Router, private myTweet:PostService, private webRequest: WebrequestService) {
   }

  ngOnInit(): void {
    this.postTweet=this.formbuilder.group({
      message: ['',Validators.required]
    })
  }

  get postTweetControl(){
    return this.postTweet.controls;
  }
  tweetOwner= localStorage.getItem('email');

  postTweets(){
      
      this.messageTweet= {tweetId: 0,tweetMessage: this.postTweetControl.message.value, ownerName:this.tweetOwner, tweetDate: null};
      console.log(this.messageTweet);
      this.webRequest.postTweet(this.messageTweet).subscribe((data : {})=> {
        this.router.navigateByUrl("/home/mytweet");
      })
      // this.myTweet.addTweetToMYTweet(this.postTweetControl.message.value);
      // alert("tweet posted successfuly");
      // localStorage.setItem('message',this.postTweetControl.message.value);
      // this.router.navigateByUrl("/home/mytweet");
  }

}

export class Tweet {
   tweetId: number;
   tweetMessage: String;
   ownerName: String;
   tweetDate: Date;
}
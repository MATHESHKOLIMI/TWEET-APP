import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AlltweetsComponent } from './alltweets.component';

describe('AlltweetsComponent', () => {
  let component: AlltweetsComponent;
  let fixture: ComponentFixture<AlltweetsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AlltweetsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AlltweetsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { PostService } from '../service/post.service';
import { Tweet } from '../Tweet';

@Component({
  selector: 'app-alltweets',
  templateUrl: './alltweets.component.html',
  styleUrls: ['./alltweets.component.css']
})
export class AlltweetsComponent implements OnInit {

  // message:String;
  // getTweets:String;
  constructor(private router:Router, private post : PostService, private http: HttpClient) {
   }
   Tweets: any = [];
  //  allTweets:any = [];
  ngOnInit(): void {
    this.loadingTweet();
    // console.log(this.Tweets);
    // console.log(this.allTweets);
  }
  loadingTweet(){    
    return this.getTweet().subscribe((data: Tweet) => {
       this.Tweets=data;
      console.log(data);
      this.showTweets();
    });
    console.log();
  }
  showTweets(){
    console.log(this.Tweets);
  }
  getTweet() : Observable<Tweet>{
    return this.http.get<Tweet>("http://localhost:8090/get-tweets");
  }
  // data: Array<any>
  // message:String;
  // constructor(private router:Router, private post : PostService) {
  //   this.data = [
  //     { firstName: 'John', tweet:"hello this is my first tweet", date:"11/02/2021" },
  //     { firstName: 'Michael',tweet:"hello this is my first tweet and i am exited about it thanks for the support i love you all guys once again thanks for the support and i am thankful for everything i have now forever greateful                     ", date:"15/02/2021" },
  //     { firstName: 'Michael', lastName: 'Jordan', age: '45' },
  //     { firstName: 'Tanya', lastName: 'Blake', age: '47' }
  // ];
  //  }
  //  localData:Array<any>;
  // ngOnInit(): void {
  //   this.localData=JSON.parse(localStorage.getItem('tweets') || "[]");
  //   if(localStorage.getItem('message') !== null){
  //   this.localData.push({firstName:localStorage.getItem('email'), tweet:localStorage.getItem('message'), date:new Date()});
  //   localStorage.setItem('tweets',JSON.stringify(this.localData));
  //   localStorage.removeItem('message');
  //   }
  // }
  
  // postTweet(){
  //     this.router.navigateByUrl("/home/post");
      
  // }
  // addTweetToMYTweet(){
  //     this.message=this.post.getTweetMessage();
  //     console.log(this.data);
  //     // localStorage.
  //     localStorage.removeItem('message');
  // }

}

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { WebrequestService } from '../service/webrequest.service';
import { User } from '../User';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  loginForm: FormGroup;
  status: String;
  loginUser: User;
  submitted = false;
  constructor(private formBuilder: FormBuilder, private navigate: Router, private webRequest:WebrequestService) { }

  ngOnInit(): void {
    this.loginForm= this.formBuilder.group({
      email:['',[Validators.required,Validators.email]],
      password:['',Validators.required],
    });
  }
  get loginController(){
      return this.loginForm.controls;
  }
  login(){
    this.loginUser= {email: this.loginController.email.value,password: this.loginController.password.value, userId:null,firstName:null,lastName:null,dateOfBirth:null,gender:null};
    this.webRequest.getUser(this.loginUser).subscribe((data: any) => {
      this.status=data.status;
      // console.log(data);
      console.log(this.status);

      
      if(this.status==="Success"){
                
          localStorage.setItem('email',this.loginController.email.value);
          this.navigate.navigateByUrl('/home/mytweet');
      }
      else{
        alert('wrong password');
        this.loginForm.get('password').setValue('');
        localStorage.removeItem('email');
        this.navigate.navigateByUrl('/login');
      }
    //  console.log(this.loginUser);
    //  this.showTweets();
   });
    // this.submitted=true;
    // if(this.loginForm.valid){
    // console.table(this.loginForm.value);
    // localStorage.setItem('email',this.loginController.email.value);
    // this.navigate.navigateByUrl('/home/mytweet');
    }
  }


// }

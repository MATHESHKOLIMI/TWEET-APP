import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Tweet } from '../Tweet';
import { User } from '../User';

@Injectable({
  providedIn: 'root'
})
export class WebrequestService {

  params =new HttpParams();
  url="http://localhost:8090"
  constructor(private http:HttpClient) { }

  getTweetByUserName(userName:String): Observable<Tweet>{
    return this.http.get<Tweet>(this.url+"/get-tweet-by-username/"+userName);
  }
  postTweet(message: Tweet): Observable<Tweet>{
    return this.http.post<Tweet>(this.url+"/post-tweet", message);
  }
  getUser(user: User): Observable<any>{
    return this.http.post<any>(this.url+"/get-user",user,{responseType: 'json'});
  }
  postUser(user : User): Observable<any>{
    return this.http.post<any>(this.url+"/create-user",user);
  }
  resetUserPassword(user : User , updatedUser: User): Observable<any>{
    return this.http.post<any>(this.url+"/reset-password",[user, updatedUser]);
  }
}

// let params = new HttpParams();
// params = params.append("page", 1);
// ....
// this.httpClient.get<any>(apiUrl, {params: params});


  // // HttpClient API post() method => Create employee
  // createEmployee(employee): Observable<Employee> {
  //   return this.http.post<Employee>(this.apiURL + '/employees', JSON.stringify(employee), this.httpOptions)
  //   .pipe(
  //     retry(1),
  //     catchError(this.handleError)
  //   )
  // }  


  // // HttpClient API put() method => Update employee
  // updateEmployee(id, employee): Observable<Employee> {
  //   return this.http.put<Employee>(this.apiURL + '/employees/' + id, JSON.stringify(employee), this.httpOptions)
  //   .pipe(
  //     retry(1),
  //     catchError(this.handleError)
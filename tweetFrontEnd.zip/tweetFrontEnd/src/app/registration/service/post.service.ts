import { Injectable } from '@angular/core';
import { MytweetComponent } from '../mytweet/mytweet.component';

@Injectable({
  providedIn: 'root'
})
export class PostService {

  tweet:String;
  constructor() { 

  }

  addTweetToMYTweet(message:String){
      this.tweet=message;
  }

  getTweetMessage(){
    return this.tweet;
  }
}

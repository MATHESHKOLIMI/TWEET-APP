import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { WebrequestService } from '../service/webrequest.service';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  searchForm: FormGroup;
  UserName: String;
  Tweets: any=[];
  constructor( private formbuilder:FormBuilder , private webRequest: WebrequestService, private router:Router) { }
  // field:String;
  
  ngOnInit(): void {
    this.searchForm=this.formbuilder.group({
      field:['',Validators.required],
    });
    this.UserName=localStorage.getItem('email');
  }

  logout(){
    localStorage.removeItem('email');
    localStorage.removeItem('tweets');
    
    localStorage.removeItem('message');
  }
  get searchFormControl(){
    return this.searchForm.controls;
  }
  search(){
    this.router.navigateByUrl("/home/alltweets")
    // this.searchByUserName(this.searchFormControl.field.value);
    // console.log(this.searchFormControl.field.value);
  }
  
  searchByUserName(field:String) {
    return this.webRequest.getTweetByUserName(field).subscribe((data:{})=>{
      this.Tweets=data;
    })
  }
}


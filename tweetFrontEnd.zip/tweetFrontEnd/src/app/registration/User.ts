export class User {
    userId: String;
    firstName: String;
    lastName: String;
    dateOfBirth: Date;
    email:String;
    password: String;
    gender: String;
 }
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup } from '@angular/forms';
import {Validators} from '@angular/forms';
import { Router } from '@angular/router';
import { ValidationService } from '../service/validation.service';
import { WebrequestService } from '../service/webrequest.service';
import { User } from '../User';
@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registration: FormGroup;
  submitted = false;
  user: User;
  status: String;

  constructor( private formBuilder : FormBuilder,
    private custom: ValidationService,
    private webRequest: WebrequestService,
    private router: Router
    ) { }

  ngOnInit(): void {
  this.registration= this.formBuilder.group({
  firstName: ['',[Validators.required,Validators.minLength(3),Validators.maxLength(16)]],
  lastName: ['',[Validators.required,Validators.minLength(3),Validators.maxLength(16)]],
  email: ['',[Validators.required,Validators.email]],
  Gender: ['',[Validators.required]],
  mobileNo: ['',[Validators.required,Validators.minLength(10),Validators.maxLength(10)]],
  password: ['',Validators.compose([Validators.required,this.custom.patternValidator()])],
  confirmPassword: ['',Validators.required],
},
{validator: this.custom.MatchPassword('password','confirmPassword')});
  }

  
  get registrationControl() {
    return this.registration.controls;
  }

  get firstName(){
    return this.registration.get('firstName');
  }
submit(){
  this.user={email: this.registrationControl.email.value,password: this.registrationControl.password.value, userId: null,firstName:this.registrationControl.firstName.value,lastName:this.registrationControl.lastName.value,dateOfBirth:null, gender: this.registrationControl.Gender.value};
  
          console.table(this.user);
  this.webRequest.postUser(this.user).subscribe((data : any)=>{
    this.status=data.status;
    console.log(this.status);
    
    if (this.status==="Success") {
          alert('Form Submitted succesfully!!!\n please login');
          this.router.navigateByUrl("/login");
          // console.table(this.registration.value);
        }
        else {
          alert('Form has some errors !!!\n please retry');
          // this.router.navigateByUrl("/login");
          // console.table(this.registration.value);
        }
  })
  // this.submitted = true;
  //   if (this.registration.valid) {
  //     alert('Form Submitted succesfully!!!\n Check the values in browser console.');
  //     console.table(this.registration.value);
  //   }
  }
}



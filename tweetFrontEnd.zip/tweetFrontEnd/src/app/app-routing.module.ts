import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppComponent } from './app.component';
import { AlltweetsComponent } from './registration/alltweets/alltweets.component';
import { ForgotPasswordComponent } from './registration/forgot-password/forgot-password.component';
import { HomeComponent } from './registration/home/home.component';
import { LoginComponent } from './registration/login/login.component';
import { MytweetComponent } from './registration/mytweet/mytweet.component';
import { PostTweetComponent } from './registration/post-tweet/post-tweet.component';
import { RegisterComponent } from './registration/register/register.component';
import { ResetPasswordComponent } from './registration/reset-password/reset-password.component';


const routes: Routes = [
  {path:"register", component: RegisterComponent},
  {path:"login", component: LoginComponent},
  {path:"home", component: HomeComponent, children:[
    {path:"mytweet", component: MytweetComponent},
    {path:"alltweets", component: AlltweetsComponent},
    {path:"post", component: PostTweetComponent},
  ]},
  
  {path:"resetpassword", component: ResetPasswordComponent},
  {path:"forgotpassword", component: ForgotPasswordComponent},
  {path:"", redirectTo : '/home/mytweet', pathMatch: 'full'},
  {path:"**", component: AppComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
